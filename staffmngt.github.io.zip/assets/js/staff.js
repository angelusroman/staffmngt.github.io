$(document).ready(function(){

	/* click to show add staff */
		$('.addnewstaff').on('click',function(event){
			event.preventDefault();

			$("#addModal").modal({
			backdrop: 'static',
    		keyboard: false 
			});

			$("#name").val('');
			$("#identity").val('');
			$("#identity").attr('disabled',false);
			$("#gender").val('');
			$("#depart").val('');

			$("#crtbtn").html('<button type="submit" class="btn btn-success btn-sm">Click to add</button>');
		});
	/* click to show add staff */

	/* add new staff */
	$(document).on('submit','#addstaff',function(event){
		event.preventDefault();
		if($('#name').val()=="")
		{

			$('#addstaff_name_errorloc').html('<i>Required fullname</i>');
		}
		else if($('#identity').val()==""){
			$('#addstaff_id_errorloc').html('<i>Required ID</i>');
		}
		else if($('#gender').val()==""){
			$('#addstaff_gender_errorloc').html('<i>Required gender</i>');
		}
		else if($('#depart').val()==""){
			$('#addstaff_depart_errorloc').html('<i>Required Department</i>');
		}
		else
		{
			$('#addstaff_name_errorloc').html('');
			$('#addstaff_id_errorloc').html('');
			$('#addstaff_gender_errorloc').html('');
			$('#addstaff_depart_errorloc').html('');

			$.ajax({
				url:'http://localhost/Staff_system/index.php/Staffs/addStaff',
				method:'post',
				dataType:'text',
				data:{'action':'add', 'name':$('#name').val(), 'id':$('#identity').val(), 'gender':$('#gender').val(), 'depart':$('#depart').val() },
				success:function(data){
					if(data =="true"){
						location.reload(true);
					}
					else if(data=="exists")
					{
						$('.ld').html('<i>staff with that ID exists alread</i>');
					}
				},
				error:function(xx){
					console.log(xx);
					$('.ld').html('<i>Fail to add record</i>');
				}
			});
		}
		
	});

	/* add new staff */



/* delete record */	

	$('.deleteshow').on('click',function(event){
		event.preventDefault();
		$("#deletemodal").modal({
			backdrop:'static',
			keyboard:false
		});

		$('#m_id').html($(this).data('datac'));
		var userid = $(this).val();
		$('.delete').on('click',function(event){
			event.preventDefault();
			deleteData(userid);
		});
	});

	function deleteData(u_id){
		$.ajax({
			url:'http://localhost/Staff_system/index.php/Staffs/addStaff',
			method:'post',
			dataType:'text',
			data:{'action':'deleted', 'val':u_id },
			success:function(data){
				location.reload(true);
			},
			error:function(xx){
				console.log(xx);
			}
		});
	}

/* delete record */	


/* edit */
	$('.edit').on('click',function(event){
		event.preventDefault();

		$("#addModal").modal({
			backdrop: 'static',
    		keyboard: false 
		});

			$.ajax({
				url:'http://localhost/Staff_system/index.php/Staffs/addStaff',
				method:'post',
				dataType:'text',
				data:{'action':'edit', 'val':$(this).val() },
				success:function(data){
					//console.log(data);
					var obj = JSON.parse(data);
					$("#name").val(obj.name);
					$("#identity").val(obj.id);
					$("#identity").attr('disabled',true);
					$("#gender").val(obj.gender);
					$("#depart").val(obj.department);
					$("#crtbtn").html('<button type="submit" class="btn btn-success btn-sm">Save Cahnges</button>');

					/* save change button is clicked*/
					$("#crtbtn").on('click',function(event){
						event.preventDefault();
						/*@@@@@@@@@@@@@*/
							if($('#name').val()=="")
							{
								$('#addstaff_name_errorloc').html('<i>Required fullname</i>');
							}
							else if($('#identity').val()==""){
								$('#addstaff_id_errorloc').html('<i>Required ID</i>');
							}
							else if($('#gender').val()==""){
								$('#addstaff_gender_errorloc').html('<i>Required gender</i>');
							}
							else if($('#depart').val()==""){
								$('#addstaff_depart_errorloc').html('<i>Required Department</i>');
							}
							else
							{
								$('#addstaff_name_errorloc').html('');
								$('#addstaff_id_errorloc').html('');
								$('#addstaff_gender_errorloc').html('');
								$('#addstaff_depart_errorloc').html('');

								$.ajax({
									url:'http://localhost/Staff_system/index.php/Staffs/addStaff',
									method:'post',
									dataType:'text',
									data:{'action':'savechanges', 'name':$('#name').val(), 'id':$('#identity').val(), 'gender':$('#gender').val(), 'depart':$('#depart').val() },
									success:function(data){
										if(data =="true"){
											location.reload(true);
										}
									},
									error:function(xx){
										console.log(xx);
										$('.ld').html('<i>Fail to save record</i>');
									}
								});
							}
						/*@@@@@@@@@@@@@*/
					});

					/* save change button is clicked */
				},
				error:function(xx){
					console.log(xx);
				}
			});


	});

/* edit */







});