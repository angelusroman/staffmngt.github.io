$(document).ready(function(){
	
	/* attach files */
	$('.attachbtn').on('click',function(event){
		event.preventDefault();
		$("#attahcfiles").modal({
			backdrop:'static',
			keyboard:false
		});
	});


		/* save file */

		$(document).on('submit','#attachForm',function(event){
		event.preventDefault();

		if($('input[name="userfile"]').val() ==''){
			$('.errFile').html('<i class="error">Browse a file to upload please</i>');
		}
		else
		{
			$('.errFile').html('');
			var ext = $('input[name="userfile"]').val().split('.').pop().toLowerCase();
			if(jQuery.inArray(ext,['pdf','jpg','jpeg','png','gif']) == -1){
				$('.errFile').html('<i class="error">Only PDF and IMAGE files are allowed</i>');
				$(this)[0].reset();
			}
			else{
				$(".errFile").html('');
				$(".ld").html(" Please wait... ");
				$("button").prop("disabled",true);
				var formdata = new FormData();
				formdata.set('userfile',$('input[type=file]')[0].files[0]);
				$.ajax({
					url: 'http://localhost/Staff_system/index.php/Staffs/saveFile',
					type: 'POST',
					dataType: 'text',
					contentType: false,
					processData: false,
					data: formdata ,
					success: function(data){
						
						location.reload(true);
					},
					error: function(x){
						console.log(x);
					}

				});
			}
		}
	});
	/* save file */


/* attach files */



/* delete files */
	$('.delfile').on('click',function(event){
		$('#deleteAttached').modal({
			backdrop:'static',
			keyboard:false
		});
		$('.file_id').html($(this).data('datac'));
		$('.yesbtn').val($(this).val());
		$('.yesbtn').on('click',function(event){
			event.preventDefault();
			$.ajax({
				url:'http://localhost/Staff_system/index.php/Staffs/deleteFile',
				method:'post',
				dataType:'text',
				data:{'action':'deletedfiles', 'val':$('.yesbtn').val() },
				success:function(data){
					location.reload(true);
				},
				error:function(xx){
					console.log(xx);
				}
			});
		})
	});


	
/* delete files */


});