<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Staffs extends CI_Controller
{
	public function index($page = "staffs")
	{
		if(!isset($_SESSION['user_id'])){ redirect('Pages/logout');}
		if(!file_exists(APPPATH.'views/pages/'.$page.'.php'))
		{
			show_404();
		}

		$data['records'] = $this->My_model->get_result('members',FALSE,FALSE);

		$data['title'] = ucfirst($page);
		$this->load->view('templates/header_in',$data);
		$this->load->view('pages/'.$page);
		$this->load->view('templates/footer');
	}

	public function addStaff(){

		if($this->input->post('action')==="add")
		{
			$checkstaff = $this->My_model->getdata('members','id',$this->input->post('id'));
			if(!empty($checkstaff))
			{
				echo "exists";
			}
			else
			{
				$data = array(
					'id'=>$this->input->post('id'),
					'name'=>$this->input->post('name'),
					'gender'=>$this->input->post('gender'),
					'department'=>$this->input->post('depart')
					);
				//$data = $this->security->xss_clean($data);
				if($this->My_model->datasave('members',$data)===TRUE)
				{
					echo "true";
				}
			}
		}
		elseif ($this->input->post('action') ==="deleted") {

			$this->My_model->deletedata('members','id',$this->input->post('val'));
		}
		elseif ($this->input->post('action')==="edit") {

			$getmember = $this->My_model->getdata('members','id',$this->input->post('val'));
			echo json_encode($getmember);
		}
		elseif ($this->input->post('action')==="savechanges") {
			$data = array(
				'id'=>$this->input->post('id'),
				'name'=>$this->input->post('name'),
				'gender'=>$this->input->post('gender'),
				'department'=>$this->input->post('depart')
				);
			//$data = $this->security->xss_clean($data);
			if($this->My_model->updatedata('members',$data)===TRUE)
			{
				echo "true";
			}
		}
	}





public function mFiles(){
	if($this->input->post('vfilesbtn'))
	{
		$_SESSION['s_id'] = $this->input->post('vfilesbtn');
		redirect('Staffs/files');
	}
}




public function saveFile()
{
	if(!empty($_FILES['userfile']['name']))
	{
		$extens = explode('.', $_FILES['userfile']['name']);
		$path_part = pathinfo($_FILES['userfile']['name']);
		$ext = $path_part['extension'];
		$file = $this->My_model->getLast('files','id',$_SESSION['s_id'],'filename','DESC');
		if(!empty($file))
		{
			$name = intval(substr($file['filename'], 0));
			$name += 1;
			$tranc = str_replace('.', '_', $_SESSION['user_id']);
			$newname = $name.'_'.$tranc.$file['id'].'.'.$ext;
			$destination = './assets/Attach/'.$newname;
			move_uploaded_file($_FILES['userfile']['tmp_name'], $destination);
			if(file_exists($destination))
			{
				$data = array(
					'id' => $_SESSION['s_id'],
					'filename' => $newname
					);
					$this->My_model->datasave('files',$data);
			}
		}
		else
		{
			
			$tranc = str_replace('.', '_', $_SESSION['user_id']);
			$newname = '1_'.$tranc.$_SESSION['s_id'].'.'.$ext;
			$destination = './assets/Attach/'.$newname;
			move_uploaded_file($_FILES['userfile']['tmp_name'], $destination);
			if(file_exists($destination))
			{
				
					$data = array(
						'id' => $_SESSION['s_id'],
						'filename' => $newname
					);
					$this->My_model->datasave('files',$data);
			}
		}
		
	}
	else{
	echo 'no file';
	}
}



######## delete file ################

public function deleteFile(){
	if($this->input->post('action')==="deletedfiles")
	{
		$getfile = $this->My_model->getdata('files','filename',$this->input->post('val'));
		$this->My_model->deletedata('files','filename',$this->input->post('val'));
		unlink('./assets/Attach/'.$getfile['filename']);
	}
}
######## delete file ################

}