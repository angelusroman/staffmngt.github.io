<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pages extends CI_Controller
{
	public function index($page = "home")
	{
		if(!file_exists(APPPATH.'views/pages/'.$page.'.php'))
		{
			show_404();
		}

		$data['title'] = ucfirst($page);
		$this->load->view('templates/header',$data);
		$this->load->view('pages/'.$page);
		$this->load->view('templates/footer');
	}

			//login
	public function user_in(){
		$user_data = $this->My_model->get_user(trim($this->input->post('username')), trim($this->input->post('password')));
        if(!empty($user_data)){
            $_SESSION['name'] = $user_data->name; 	
            $_SESSION['user_id'] = $user_data->username; 
            
            redirect('Staffs/staffs');
            
        }
        else
        {
            $data['fail_log'] = "Enter correct credentials";
            $data['title'] = ucfirst('home');
            $this->load->view('templates/header',$data);
            $this->load->view('pages/home',$data);
            $this->load->view('templates/footer');
        }
	}


		// lgout
	public function logout(){
		unset($_SESSION['name']);
		unset($_SESSION['user_id']);
		session_destroy();
		redirect('home');
	}



}