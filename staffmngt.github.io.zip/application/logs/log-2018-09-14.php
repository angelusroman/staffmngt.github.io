<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-14 12:36:31 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\Staff_system\application\controllers\Staffs.php 45
