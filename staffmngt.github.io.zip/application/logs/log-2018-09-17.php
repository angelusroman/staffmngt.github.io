<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-09-17 14:50:39 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 14:50:39 --> No URI present. Default controller set.
DEBUG - 2018-09-17 14:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 14:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 14:50:39 --> Total execution time: 0.1540
DEBUG - 2018-09-17 15:15:22 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:15:22 --> No URI present. Default controller set.
DEBUG - 2018-09-17 15:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:15:22 --> Total execution time: 0.2530
DEBUG - 2018-09-17 15:19:40 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:19:40 --> No URI present. Default controller set.
DEBUG - 2018-09-17 15:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:19:41 --> Total execution time: 0.1700
DEBUG - 2018-09-17 15:19:55 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:19:55 --> No URI present. Default controller set.
DEBUG - 2018-09-17 15:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:19:55 --> Total execution time: 0.2070
DEBUG - 2018-09-17 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:20:19 --> Total execution time: 0.5590
DEBUG - 2018-09-17 15:20:26 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:20:30 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:20:30 --> No URI present. Default controller set.
DEBUG - 2018-09-17 15:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:20:30 --> Total execution time: 0.2000
DEBUG - 2018-09-17 15:20:35 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:20:35 --> No URI present. Default controller set.
DEBUG - 2018-09-17 15:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:20:35 --> Total execution time: 0.1720
DEBUG - 2018-09-17 15:20:38 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:20:38 --> No URI present. Default controller set.
DEBUG - 2018-09-17 15:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:20:38 --> Total execution time: 0.1740
DEBUG - 2018-09-17 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:21:15 --> Total execution time: 0.2650
DEBUG - 2018-09-17 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-09-17 15:21:35 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\Staff_system\application\controllers\Staffs.php 45
DEBUG - 2018-09-17 15:22:17 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:22:17 --> Total execution time: 0.1530
DEBUG - 2018-09-17 15:22:23 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:22:23 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:22:23 --> Total execution time: 0.1570
DEBUG - 2018-09-17 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2018-09-17 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-09-17 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2018-09-17 15:22:25 --> Total execution time: 0.1190
