<?php
defined('BASEPATH')or exit('No direct script access allowed');
class My_model extends CI_Model{

	public function get_user($username,$password){

        $this->db->where('username',$username);
        $this->db->where('password',$password);
        $qry = $this->db->get('users');

        return $qry->row();
         
	}


	public function datasave($table,$data){
	    if($this->db->insert($table,$data))
	    {
	        return TRUE;
	    }
	}


	public function getdata($table,$column,$slug){
            $this->db->where($column,$slug);
            $qry = $this->db->get($table);
           
                return $qry->row_array();
        }


    public function get_result($table,$column,$slug){
    	if($column ===FALSE && $slug ===FALSE)
    	{
    		$qry = $this->db->get($table);
            return $qry->result_array();
    	}
    	else
    	{
    		$this->db->where($column,$slug);
            $qry = $this->db->get($table);
            return $qry->result_array();
    	}
            
            
    }

    public function deletedata($table,$column,$slug){
        $this->db->where($column,$slug);
        $this->db->delete($table);
    }


    public function updatedata($table,$data){
		if($this->db->replace($table,$data))
		{
			return TRUE;
		}
	}

	public function getLast($table,$col,$slug,$order,$flag){
		$this->db->where($col,$slug);
		$this->db->order_by($order,$flag);
		$result = $this->db->get($table);
		return $result->row_array();
	}


}