<section>

	<center>
		<?php echo form_open('Staffs/mFiles','name="manageForm" method="post"');?>
		<div class="col-sm-12" style="float:none;">
			<div class="panel panel-default">

				<div class="panel-heading text-left">
					<h4><strong>Manage Your Staffs</strong>
						<span style=" float:right;">
					  		<button type="button" class="btn btn-success btn-xs addnewstaff" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Add new patient" > <i class="glyphicon glyphicon-plus"></i> </button>
						</span>
					</h4>
				</div>
				<div class="panel-body text-left">
					<br>
					<div class="table-responsive">
						<table class="table table-striped table-condensed ">
							<tr style="background:#0D47A1; color:#fff;">
								<th></th>
								<th>Name</th>
								<th>Staff ID</th>
								<th>Gender</th>
								<th>Department</th>
								<th colspan="3">Actions</th>
							</tr>
						  	<?php if(!empty($records)): $i=0; ?>
						  		<?php foreach ($records as $key => $value) :?>
						  			<?php $i++;?>
						  			<tr class="fade-in">
						  				<td><?= $i;?></td>
						  				<td><?= $value['name'];?></td>
						  				<td><?= $value['id'];?></td>
						  				<td><?= $value['gender'];?></td>
						  				<td  style="width:50%;"><?= $value['department'];?></td>
						  				<td><button class="btn btn-sm btn-default" name="vfilesbtn" value="<?= $value['id'];?>" style="color:blue;"><span class="glyphicon glyphicon-eye-open"></span> View Files</button></td>
						  				<td><button class="btn btn-default btn-sm edit" value="<?= $value['id'];?>" style="color:blue;"><span class="glyphicon glyphicon-pencil"></span> Edit</button></td>
						  				<td><button class="btn btn-default btn-sm deleteshow" data-datac="<?= $value['name'];?>" value="<?= $value['id'];?>" style="color:blue;"><span class="glyphicon glyphicon-trash"></span></button></td>
						  			</tr>
						  		<?php endforeach;?>
						  	<?php endif;?>
					  	</table>
					</div>

				</div>
			</div>
		</div>
		<?php echo form_close();?>
	</center>


	<!-- Modal Add new user -->
			<div class="modal fade" id="addModal" role="dialog">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title">Fill Staff's details</h5>
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true">&times;</span>
			        </button>
			      </div>

			    <?php echo form_open('','id="addstaff" method="post"');?>

			      	<div class="modal-body text-left">
			        
						<div class="form-group">
		                  <label class="col-form-label col-form-label" for="Name">Full name</label>
		                  &emsp;<i class="error" id="addstaff_name_errorloc"></i>
		                  <input class="form-control form-control" type="text" id="name">
		                </div>

		                <div class="form-group">
		                  <label class="col-form-label col-form-label" for="id">ID</label>
		                  &emsp;<i class="error" id="addstaff_id_errorloc"></i>
		                  <input class="form-control form-control" type="text" id="identity">
		                </div>

		                <div class="form-group">
		                 	<label class="col-form-label col-form-label" for="gender">Gender</label>
		                 	&emsp;<i class="error" id="addstaff_gender_errorloc"></i>
					      <select class="form-control" id="gender">
					      	<option></option>
					        <option>Male</option>
					        <option>Female</option>
					      </select>
					    </div>

		                <div class="form-group">
		                 	<label class="col-form-label col-form-label" for="department">Department</label>
		                 	&emsp;<i class="error" id="addstaff_depart_errorloc"></i>
					      <select class="form-control" id="depart">
					      	<option></option>
					        <option>ICT</option>
					        <option>Account</option>
					        <option>Procurement</option>

					      </select>
					    </div>

				    </div>

					    <div class="modal-footer ">
					    	<span class="ld"></span>
					        <span id="crtbtn"></span>&emsp;
					        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">cancel</button>
					    </div>

				<?php echo form_close();?>
				<script src="<?= base_url(); ?>assets/js/staff.js"></script>
			    </div>
			  </div>
			</div>
			<!-- Modal Add new staff -->

			<!-- delete staff -->
				<div class="modal fade" id="deletemodal" role="dialog">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
						        <h5 class="modal-title">Delete Record</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						    </div>
						    <div class="modal-body">
						    	<p>Are you sure you want to delete <b id="m_id"></b></p>
						    </div>
						    <div class="modal-footer ">
						    	<button class="btn btn-dark btn-sm delete" name="" value="">Yes</button>&emsp;
						        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">cancel</button>
						    </div>
						</div>
					</div>
				</div>
			<!-- delete staff -->


			


</section>