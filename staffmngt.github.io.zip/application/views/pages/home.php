<section>

	<center>

		<div class="col-sm-5" style="float:none;">

			<div><h3>Staff Management System</h3></div>
			<div class="alert alert-info"><h4>Log in to access the system</h4></div>

			<?= form_open('Pages/user_in','name="login" id="login" method="post"');?>

			 <div class="card card-deaful text-left fade-in">
			 	<div class="card-body">
			 		<?php if(!empty($fail_log)) :?>
			 			<div class="alert alert-danger"><a class="close" href="#" data-dismiss="alert">&times;</a><?= $fail_log; ?></div>
			 		<?php endif;?>
			 		<div class="form-group">
					    <label class="" for="email">Username</label>
					    <input type="text" class="form-control" name="username">
					  </div>

					  <div class="form-group">
					    <label class="" for="email">Password</label>
					    <input type="text" class="form-control" name="password">
					  </div>

					  <button class="btn btn-sm btn-primary" type="submit">Log in</button>
			 	</div>
			 </div>


			<?= form_close();?>
		</div>

	</center>
</section>