<section>
	<?php $getfiles = $this->My_model->get_result('files','id',$_SESSION['s_id']); ?>
	<?php $getnames = $this->My_model->getdata('members','id',$_SESSION['s_id']); ?>
	<center>
		<?php echo form_open('','name="manageForm" method="post"');?>
		<div class="col-sm-12" style="float:none;">
			<div class="panel panel-default">

				<div class="panel-heading text-left">
					<h4><strong><?= $getnames['name'];?>'s Files</strong>
						<span style=" float:right;">
					  		<button type="button" class="btn btn-success btn-xs attachbtn"> <span class="glyphicon glyphicon-paperclip"></span> Attach File </button>
						</span>
					</h4>
				</div>
				<div class="panel-body text-left">
					<br>
					<div class="table-responsive">
						<?php if(!empty($getfiles)) : $i=0; ?>
							<table class="table table-condensed">
								<tr style="background:#0D47A1; color:#fff;">
									<th></th>
									<th>File</th>
									<th>Date atached</th>
									<th class="text-right">Actions</th>
								</tr>
								<?php foreach ($getfiles as $key => $value) : $i++?>
									<tr class="fade-in">
										<td><?= $i;?></td>
										<td><a target="_blank" href="<?= base_url()?>assets/Attach/<?= $value['filename']?>">Files Link</a></td>
										<td><?= $value['dayattached'];?></td>
										<td class="text-right"><button class="btn btn-danger btn-sm delfile" data-datac="<?= $i;?>" value="<?= $value['filename'];?>"><span class="glyphicon glyphicon-trash"></span></button></td>
									</tr>
								<?php endforeach; ?>
							</table>
						<?php endif;?>
					</div>

				</div>
			</div>
		</div>
		<?php echo form_close();?>
		<script src="<?= base_url();?>assets/js/files.js"></script>
	</center>



	<!-- Attach files -->
			<div class="modal fade" id="attahcfiles" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<?= form_open_multipart('',' id="attachForm" method="POST" ');?>
						<div class="modal-header">
							<button class="close" data-dismiss="modal">&times</button>
							<h4>Attach new File</h4>
						</div>
						
							<div class="modal-body">

								<div class="form-group">
									<input type="file" name="userfile" class="form-control" style="padding:0;">
									<span class="errFile"></span>
								</div>
						
							</div>
						
						<div class="modal-footer">
							<span class="ld"></span>
							<button type="submit" class="btn btn-primary btn-sm">Attach</button>
							<button class="btn btn-dark btn-sm" data-dismiss="modal">Cancel</button>
						</div>
						<?= form_close();?>
					</div>
				</div>
			</div>
			<!-- Attach file -->


			<!-- Delete files -->
			<div class="modal fade" id="deleteAttached" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<?= form_open_multipart('',' id="deleteAttachedForm" method="POST" ');?>
						<div class="modal-header">
							<button class="close" data-dismiss="modal">&times</button>
							<h4>Delete File</h4>
						</div>
						
							<div class="modal-body">
								<p>Are you sure you want to delete number <b class="file_id"></b></p>
							</div>
						
						<div class="modal-footer">
							<span class="ld"></span>
							<button type="submit" class="btn btn-dark btn-sm yesbtn" value="">Yes</button>
							<button class="btn btn-danger btn-sm" data-dismiss="modal">Cancel</button>
						</div>
						<?= form_close();?>
					</div>
				</div>
			</div>
			<!-- Delete file -->

</section>
