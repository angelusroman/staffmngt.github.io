<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/mystyle.css">

      
  <script type="text/javascript" src="<?= base_url().'assets/js/jquery-3.3.1.js';?>"></script>
  <script type="text/javascript" src="<?= base_url().'assets/js/bootstrap.js';?>"></script>
  </head>

    <style type="">
      .navbar-brand{
        float: none;
        padding: 0;
      }
      .navbar-brand img{
        width: 60px;
        margin-left: 30%;
      }
      .navbar-nav li{
        padding-top: 15%;
      }
    </style>
    
    <body style="">
    <!-- navbar -->
    <nav class="navbar navbar-default" style="">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span> 
          </button>
          <a class="navbar-brand" href="#"><img src="<?= base_url();?>assets/images/logo.png"></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><span class="glyphicon glyphicon-user"></span> Home</a></li>
            <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
          </ul>

        </div>
      </div>
    </nav>
  <!-- navbar -->
<div class="container" style="margin-top:100px;">
